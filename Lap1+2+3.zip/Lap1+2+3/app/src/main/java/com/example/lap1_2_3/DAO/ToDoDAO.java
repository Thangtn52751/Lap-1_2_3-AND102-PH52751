package com.example.lap1_2_3.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.lap1_2_3.DBhelper.DBhelper;
import com.example.lap1_2_3.Model.ToDoModel;

import java.util.ArrayList;

public class ToDoDAO {
    private DBhelper dBhelper;
    private SQLiteDatabase db;

    public ToDoDAO(Context context) {
        dBhelper = new DBhelper(context); //Tạo csdl mới
        db = dBhelper.getWritableDatabase(); //Mở csdl
    }


    //Thêm vào csdl
    public long addToDo(ToDoModel tdm) {
        db = dBhelper.getWritableDatabase();
        //Tạo content values
        ContentValues values = new ContentValues();
        values.put("title", tdm.getTitle());
        values.put("content", tdm.getContent());
        values.put("date", tdm.getDate());
        values.put("type", tdm.getType());
        long kq = db.insert("ToDo", null, values);
        if(kq <= 0) {
            return -1;
        }
        return 1;
    }

    public long updateToDo(ToDoModel tdm) {
        db = dBhelper.getWritableDatabase();
        //Tạo content values
        ContentValues values = new ContentValues();
        values.put("id", tdm.getId());
        values.put("title", tdm.getTitle());
        values.put("content", tdm.getContent());
        values.put("date", tdm.getDate());
        values.put("type", tdm.getType());
        values.put("status", tdm.getStatus());
        //Câp nhật
        long kq = db.update("ToDo", values, "id=?", new String[]{String.valueOf(tdm.getId())});
        if(kq <= 0) {
            return -1; //Cập nhật thất bại
        }
        return 1; //Cập nhật thành công
    }

    public ArrayList<ToDoModel> getAllToDo() {
        ArrayList<ToDoModel> list = new ArrayList<>();
        db = dBhelper.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("SELECT * FROM ToDo", null);
            if(cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    list.add(new ToDoModel(cursor.getInt(0),
                            cursor.getString(1),
                            cursor.getString(2),
                            cursor.getString(3),
                            cursor.getString(4),
                            cursor.getInt(5)));
                }while(cursor.moveToNext());
            }
        }catch (Exception e) {
            Log.e("System","Lỗi truy vấn dữ liệu");
        }
        return list;
    }

    public boolean deleteToDo(int id) {
        int kq = db.delete("ToDo","id=?",new String[]{String.valueOf(id)});
        return kq != -1;
    }

    public boolean updateTypeToDo(int id, boolean check) {
        int status = check ? 1:0;
        ContentValues values = new ContentValues();
        values.put("status", status);
        long kq = db.update("ToDo",values,"id=?",new String[]{String.valueOf(id)});
        return kq != -1;
    }
}
