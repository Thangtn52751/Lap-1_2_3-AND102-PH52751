package com.example.lap1_2_3.DBhelper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBhelper extends SQLiteOpenHelper{

    public DBhelper(Context context) {
        super(context, "ToDoList", null, 1); //Tạo database
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Tạo bảng trong database
        String sql = "CREATE TABLE ToDo" +
                " (ID      INTEGER PRIMARY KEY AUTOINCREMENT,TITLE   TEXT,CONTENT TEXT,DATE    TEXT,TYPE    TEXT,STATUS  INTEGER)";

        db.execSQL(sql);//Chạy câu lệnh
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(oldVersion != newVersion) {
            //Xóa bảng cũ nếu tồn tại
            String sql = "DROP TABLE IF EXISTS ToDo";
            db.execSQL(sql);//Chạy câu lệnh
            onCreate(db); //Tạo bảng mới
        }
    }
}
