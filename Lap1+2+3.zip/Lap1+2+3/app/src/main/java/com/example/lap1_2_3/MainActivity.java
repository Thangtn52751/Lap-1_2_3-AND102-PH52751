package com.example.lap1_2_3;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lap1_2_3.Adapter.ToDoAdapter;
import com.example.lap1_2_3.DAO.ToDoDAO;
import com.example.lap1_2_3.Model.ToDoModel;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ToDoDAO dao;
    ArrayList<ToDoModel> list;
    String tag = "//======";
    EditText edttitle, edtcontent, edtdate, edttype;
    Button btnAdd;
    ToDoAdapter adapter;
    RecyclerView rcToDo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        GUI(); // Ánh xạ các thành phần giao diện

        dao = new ToDoDAO(this); // Khởi tạo đối tượng DAO để làm việc với cơ sở dữ liệu
        list = dao.getAllToDo(); // Lấy danh sách to-do từ cơ sở dữ liệu
        Log.d(tag, "onCreate: " + list.size());

        // Thiết lập adapter cho RecyclerView hiển thị danh sách to-do
        adapter = new ToDoAdapter(MainActivity.this, list);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        rcToDo.setLayoutManager(linearLayoutManager);
        rcToDo.setAdapter(adapter);

        // Xử lý sự kiện khi người dùng nhấn nút Thêm
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lấy thông tin từ các EditText
                String title = edttitle.getText().toString().trim();
                String content = edtcontent.getText().toString().trim();
                String date = edtdate.getText().toString().trim();
                String type = edttype.getText().toString().trim();

                // Kiểm tra xem các trường thông tin có trống không
                if (title.isEmpty() || content.isEmpty() || date.isEmpty() || type.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                    // Hiển thị lỗi nếu các trường thông tin trống
                    if (title.isEmpty()) {
                        edttitle.setError("Title không được để trống!");
                    }
                    if (content.isEmpty()) {
                        edtcontent.setError("Content không được để trống!");
                    }
                    if (date.isEmpty()) {
                        edtdate.setError("Date không được để trống!");
                    }
                    if (type.isEmpty()) {
                        edttype.setError("Type không được để trống!");
                    }
                } else {
                    // Tạo đối tượng ToDoModel mới và thêm vào cơ sở dữ liệu
                    ToDoModel model = new ToDoModel(1, title, content, date, type, 0);
                    long check = dao.addToDo(model);
                    // Hiển thị thông báo thành công hoặc thất bại khi thêm vào cơ sở dữ liệu
                    if (check < 0) {
                        Toast.makeText(MainActivity.this, "Thêm thất bại", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Thêm thành công", Toast.LENGTH_SHORT).show();
                    }
                    // Cập nhật lại danh sách to-do và cập nhật RecyclerView
                    list = dao.getAllToDo();
                    adapter = new ToDoAdapter(MainActivity.this, list);
                    rcToDo.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                    rcToDo.setAdapter(adapter);
                    // Đặt lại các EditText sau khi thêm mới thành công
                    reset();
                    // Ẩn bàn phím sau khi nhấn nút Thêm
                    hideKeyboard();
                }
            }
        });

        // Xử lý sự kiện khi người dùng nhấp vào EditText loại
        edttype.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Hiển thị dialog cho phép người dùng chọn độ khó
                String[] arrType = {"Dễ", "Thường", "Khó"};
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Chọn độ khó!");
                builder.setIcon(R.drawable.information);
                builder.setItems(arrType, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Đặt giá trị cho EditText loại từ lựa chọn của người dùng
                        edttype.setText(arrType[which]);
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }

    // Phương thức để ánh xạ các thành phần giao diện
    public void GUI() {
        edttitle = findViewById(R.id.edttitle);
        edtcontent = findViewById(R.id.edtcontent);
        edtdate = findViewById(R.id.edtdate);
        edttype = findViewById(R.id.edttype);
        btnAdd = findViewById(R.id.btnAdd);
        rcToDo = findViewById(R.id.rcToDo);
    }

    // Phương thức để đặt lại các EditText sau khi thêm mới thành công
    public void reset() {
        edttitle.setText("");
        edtcontent.setText("");
        edtdate.setText("");
        edttype.setText("");
    }

    // Phương thức để ẩn bàn phím
    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
    }
}
