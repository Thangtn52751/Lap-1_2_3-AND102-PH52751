package com.example.lap1_2_3.Adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lap1_2_3.DAO.ToDoDAO;
import com.example.lap1_2_3.Model.ToDoModel;
import com.example.lap1_2_3.R;

import java.util.ArrayList;

public class ToDoAdapter extends RecyclerView.Adapter<ToDoAdapter.ViewHolderToDo> {
    Context context;
    ArrayList<ToDoModel> listToDo;
    ToDoDAO mydao;

    public ToDoAdapter(Context context, ArrayList<ToDoModel> listToDo) {
        this.context = context;
        this.listToDo = listToDo;
        mydao = new ToDoDAO(context);
    }

    @NonNull
    @Override
    public ViewHolderToDo onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_rctodo, parent, false);
        return new ViewHolderToDo(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderToDo holder, int position) {
        holder.tvContent.setText(listToDo.get(position).getContent());
        holder.tvDate.setText(listToDo.get(position).getDate());

        if(listToDo.get(position).getStatus() == 1) {
            holder.cbStatus.setChecked(true);
            holder.tvContent.setPaintFlags(holder.tvContent.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            holder.cbStatus.setChecked(false);
            holder.tvContent.setPaintFlags(holder.tvContent.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
        }

        holder.cbStatus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int id = listToDo.get(holder.getAdapterPosition()).getId();
                boolean checked = mydao.updateTypeToDo(id, holder.cbStatus.isChecked());
                if(checked) {
                    Toast.makeText(context, "Đổi trạng thái thành công!", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(context, "Đổi trạng thái thất bại!", Toast.LENGTH_SHORT).show();
                }

                listToDo.clear();
                listToDo = mydao.getAllToDo();
                notifyDataSetChanged();
            }
        });

        holder.ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id = listToDo.get(holder.getAdapterPosition()).getId();
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Xác nhận xóa");
                builder.setMessage("Bạn có chắc chắn muốn xóa?");
                builder.setIcon(R.drawable.delete);

                builder.setPositiveButton("Có", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        boolean delete = mydao.deleteToDo(id);
                        if(delete) {
                            Toast.makeText(context.getApplicationContext(), "Xóa thành công!", Toast.LENGTH_SHORT).show();
                            listToDo.clear();
                            listToDo = mydao.getAllToDo();
                            notifyItemRemoved(holder.getAdapterPosition());
                        }else {
                            Toast.makeText(context.getApplicationContext(), "Xóa thất bại!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                builder.setNegativeButton("Không", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        holder.ivUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create and configure an AlertDialog for updating a ToDo item
                LayoutInflater inflater = ((Activity) context).getLayoutInflater();
                View view = inflater.inflate(R.layout.update, null);
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setView(view);

                // Initialize EditText fields for updating the ToDo item
                EditText edtTitle, edtContent, edtDate, edtType;
                edtTitle = view.findViewById(R.id.edttitle1);
                edtContent = view.findViewById(R.id.edtcontent1);
                edtDate = view.findViewById(R.id.edtdate1);
                edtType = view.findViewById(R.id.edttype1);

                // Populate EditText fields with current data from selected ToDo item
                ToDoModel currentToDo = listToDo.get(holder.getAdapterPosition());
                edtTitle.setText(currentToDo.getTitle());
                edtContent.setText(currentToDo.getContent());
                edtDate.setText(currentToDo.getDate());
                edtType.setText(currentToDo.getType());

                // Configure AlertDialog properties
                builder.setTitle("Cập nhật list To Do");
                builder.setIcon(R.drawable.information);

                // Handle the positive button click (Update button)
                builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Create a new ToDoModel object with updated data
                        ToDoModel updatedToDo = new ToDoModel();
                        updatedToDo.setId(currentToDo.getId()); // Set the ID to update the correct item
                        updatedToDo.setTitle(edtTitle.getText().toString());
                        updatedToDo.setContent(edtContent.getText().toString());
                        updatedToDo.setDate(edtDate.getText().toString());
                        updatedToDo.setType(edtType.getText().toString());

                        // Update the ToDo item in the database
                        long result = mydao.updateToDo(updatedToDo);
                        if (result != -1) {
                            Toast.makeText(context, "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                            // Update the item in the RecyclerView
                            listToDo.set(holder.getAdapterPosition(), updatedToDo);
                            notifyItemChanged(holder.getAdapterPosition());
                        } else {
                            Toast.makeText(context, "Cập nhật thất bại", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                // Handle the negative button click (Cancel button)
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss(); // Dismiss the dialog if canceled
                    }
                });

                // Create and display the AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return listToDo.size();
    }

    public class ViewHolderToDo extends RecyclerView.ViewHolder {
        TextView tvContent, tvDate;
        CheckBox cbStatus;
        ImageView ivUpdate,ivDelete;

        public ViewHolderToDo(@NonNull View itemView) {
            super(itemView);
            tvContent = itemView.findViewById(R.id.tvContent);
            tvDate = itemView.findViewById(R.id.tvDate);
            cbStatus = itemView.findViewById(R.id.cbStatus);
            ivUpdate = itemView.findViewById(R.id.ivUpdate);
            ivDelete = itemView.findViewById(R.id.ivDelete);
        }
    }
}
